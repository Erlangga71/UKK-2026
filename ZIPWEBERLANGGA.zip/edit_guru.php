
<?php
session_start();

require_once "database.php";
require_once "auth.php";

hanyaRole(['admin']);

$error = "";

/* =========================
   AMBIL ID GURU
========================= */

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    die("ID guru tidak valid.");
}

/* =========================
   AMBIL DATA GURU DAN AKUN
========================= */

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT
        g.id,
        g.nama,
        g.nip,
        g.email,
        g.no_hp,
        u.id AS user_id,
        u.aktif
     FROM guru g
     LEFT JOIN users u
        ON LOWER(TRIM(u.email)) = LOWER(TRIM(g.email))
        AND u.role = 'guru'
     WHERE g.id = ?
     LIMIT 1"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$guru = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$guru) {
    die("Data guru tidak ditemukan.");
}

if (empty($guru['user_id'])) {
    die("Akun login guru tidak ditemukan. Periksa email pada tabel guru dan users.");
}

$user_id = (int)$guru['user_id'];

/* Nilai awal form */
$form = $guru;

/* =========================
   PROSES UPDATE
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama     = trim($_POST['nama'] ?? '');
    $nip      = trim($_POST['nip'] ?? '');
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $password = $_POST['password'] ?? '';
    $aktif    = isset($_POST['aktif']) ? (int)$_POST['aktif'] : -1;

    $form['nama']  = $nama;
    $form['nip']   = $nip;
    $form['email'] = $email;
    $form['no_hp'] = $no_hp;
    $form['aktif'] = $aktif;

    if ($nama === '' || $email === '') {

        $error = "Nama dan Gmail wajib diisi.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Format Gmail tidak valid.";

    } elseif ($nip !== '' && (!ctype_digit($nip) || strlen($nip) > 18)) {

        $error = "NIP hanya boleh angka dan maksimal 18 digit.";

    } elseif (!in_array($aktif, [0, 1], true)) {

        $error = "Status akun tidak valid.";

    } else {

        /* CEK EMAIL DUPLIKAT DI USERS */

        $stmt = mysqli_prepare(
            $koneksi,
            "SELECT id FROM users
             WHERE (LOWER(TRIM(email)) = LOWER(TRIM(?))
                OR LOWER(TRIM(username)) = LOWER(TRIM(?)))
             AND id != ?
             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "ssi",
            $email,
            $email,
            $user_id
        );

        mysqli_stmt_execute($stmt);

        $cek_email = mysqli_stmt_get_result($stmt);
        $email_ada = mysqli_num_rows($cek_email) > 0;

        mysqli_stmt_close($stmt);

        /* CEK EMAIL DUPLIKAT DI GURU */

        $stmt = mysqli_prepare(
            $koneksi,
            "SELECT id FROM guru
             WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))
             AND id != ?
             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "si",
            $email,
            $id
        );

        mysqli_stmt_execute($stmt);

        $cek_guru = mysqli_stmt_get_result($stmt);
        $email_guru_ada = mysqli_num_rows($cek_guru) > 0;

        mysqli_stmt_close($stmt);

        /* CEK NIP DUPLIKAT */

        $nip_ada = false;

        if ($nip !== '') {

            $stmt = mysqli_prepare(
                $koneksi,
                "SELECT id FROM guru
                 WHERE nip = ? AND id != ?
                 LIMIT 1"
            );

            mysqli_stmt_bind_param(
                $stmt,
                "si",
                $nip,
                $id
            );

            mysqli_stmt_execute($stmt);

            $cek_nip = mysqli_stmt_get_result($stmt);
            $nip_ada = mysqli_num_rows($cek_nip) > 0;

            mysqli_stmt_close($stmt);
        }

        if ($email_ada || $email_guru_ada) {

            $error = "Gmail tersebut sudah digunakan.";

        } elseif ($nip_ada) {

            $error = "NIP tersebut sudah digunakan guru lain.";

        } else {

            mysqli_begin_transaction($koneksi);

            try {

                $nip_db = ($nip === '') ? null : $nip;
                $no_hp_db = ($no_hp === '') ? null : $no_hp;

                /* UPDATE DATA GURU */

                $stmt = mysqli_prepare(
                    $koneksi,
                    "UPDATE guru
                     SET nama = ?, nip = ?, email = ?, no_hp = ?
                     WHERE id = ?"
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    "ssssi",
                    $nama,
                    $nip_db,
                    $email,
                    $no_hp_db,
                    $id
                );

                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception(mysqli_stmt_error($stmt));
                }

                mysqli_stmt_close($stmt);

                /* UPDATE AKUN LOGIN */

                if ($password === '') {

                    $stmt = mysqli_prepare(
                        $koneksi,
                        "UPDATE users
                         SET nama = ?,
                             email = ?,
                             username = ?,
                             aktif = ?
                         WHERE id = ? AND role = 'guru'"
                    );

                    mysqli_stmt_bind_param(
                        $stmt,
                        "sssii",
                        $nama,
                        $email,
                        $email,
                        $aktif,
                        $user_id
                    );

                } else {

                    $password_hash = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    $stmt = mysqli_prepare(
                        $koneksi,
                        "UPDATE users
                         SET nama = ?,
                             email = ?,
                             username = ?,
                             password = ?,
                             aktif = ?
                         WHERE id = ? AND role = 'guru'"
                    );

                    mysqli_stmt_bind_param(
                        $stmt,
                        "ssssii",
                        $nama,
                        $email,
                        $email,
                        $password_hash,
                        $aktif,
                        $user_id
                    );
                }

                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception(mysqli_stmt_error($stmt));
                }

                if (mysqli_stmt_affected_rows($stmt) < 0) {
                    throw new Exception("Gagal memperbarui akun login guru.");
                }

                mysqli_stmt_close($stmt);

                mysqli_commit($koneksi);

                header("Location: kelola_guru.php");
                exit;

            } catch (Exception $e) {

                mysqli_rollback($koneksi);

                $error = "Gagal memperbarui data: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Data Guru</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body {
    background: #f4f6f8;
    font-family: Arial, sans-serif;
    font-size: 14px;
    margin: 0;
    color: #212529;
}

/* SIDEBAR */

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 220px;
    height: 100vh;
    background: #687280;
    padding: 20px 12px;
    overflow-y: auto;
}

.sidebar-title {
    color: white;
    font-size: 19px;
    font-weight: bold;
    margin: 0 8px 25px;
    line-height: 1.4;
}

.sidebar a {
    display: block;
    padding: 11px 13px;
    margin-bottom: 5px;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 14px;
}

.sidebar a:hover,
.sidebar a.active {
    background: #4f5965;
}

.sidebar .logout {
    margin-top: 20px;
    background: #b42323;
}

.sidebar .logout:hover {
    background: #941d1d;
}

/* CONTENT */

.content {
    margin-left: 220px;
    padding: 30px;
}

/* CARD */

.card {
    border: 1px solid #ddd;
    border-radius: 6px;
    box-shadow: none;
}

.card-body {
    padding: 20px;
}

/* BUTTON */

.btn-stabilo {
    background: #9dff00;
    color: #1a3300;
    font-weight: bold;
    border: none;
}

.btn-stabilo:hover {
    background: #86e000;
    color: #1a3300;
}

/* RESPONSIVE */

@media (max-width: 700px) {

    .sidebar {
        position: relative;
        width: 100%;
        height: auto;
    }

    .content {
        margin-left: 0;
        padding: 15px;
    }
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div class="sidebar-title">
        ⚖ Pelanggaran<br>Siswa
    </div>

    <a href="dashboard.php"> Dashboard</a>
    <a href="kelola_siswa.php">Data Siswa</a>
    <a href="kelola_guru.php" class="active">Data Guru</a>
    <a href="kelola_kelas.php">Data Kelas</a>
    <a href="kelola_tahun_ajaran.php">Tahun Ajaran</a>
    <a href="kelola_wali_kelas.php">Wali Kelas</a>
    <a href="penempatan_siswa.php">Penempatan Siswa</a>
    <a href="kelola_pelanggaran_kategori.php">⚠ Kategori Pelanggaran</a>
    <a href="pelanggaran.php">Data Pelanggaran</a>
    <a href="tindakan.php">Data Tindakan</a>
    <a href="laporan.php">Laporan</a>
    <a href="about_me.php">ℹ About Me</a>

    <a href="logout.php" class="logout"> Logout</a>

</div>

<!-- CONTENT -->

<div class="content">

    <!-- HEADER -->

    <div class="card mb-3">
        <div class="card-body">

            <h4 class="mb-1">Edit Data Guru</h4>

            <p class="text-muted mb-0">
                Perbarui data guru dan akun login guru.
            </p>

        </div>
    </div>

    <!-- FORM EDIT -->

    <div class="card">

        <div class="card-body">

            <h5 class="mb-3">Form Edit Guru</h5>

            <?php if ($error !== '') { ?>

                <div class="alert alert-danger">
                    <?= htmlspecialchars($error); ?>
                </div>

            <?php } ?>

            <form method="POST">

                <div class="row g-3">

                    <div class="col-md-6">

                        <label class="form-label fw-bold">NIP</label>

                        <input
                            type="text"
                            name="nip"
                            class="form-control"
                            placeholder="Masukkan NIP"
                            value="<?= htmlspecialchars($form['nip'] ?? ''); ?>"
                            maxlength="18"
                            inputmode="numeric"
                            pattern="[0-9]{1,18}"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 18)"
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label fw-bold">Nama Guru</label>

                        <input
                            type="text"
                            name="nama"
                            class="form-control"
                            placeholder="Masukkan nama guru"
                            value="<?= htmlspecialchars($form['nama'] ?? ''); ?>"
                            required
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label fw-bold">Gmail</label>

                        <input
                            type="email"
                            name="email"
                            class="form-control"
                            placeholder="contoh@gmail.com"
                            value="<?= htmlspecialchars($form['email'] ?? ''); ?>"
                            required
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label fw-bold">Password Baru</label>

                        <input
                            type="password"
                            name="password"
                            class="form-control"
                            placeholder="Kosongkan jika tidak ingin mengganti password"
                        >

                        <small class="text-muted">
                            Password lama tetap digunakan jika dikosongkan.
                        </small>

                    </div>

                    <div class="col-md-6">

                        <label class="form-label fw-bold">No HP</label>

                        <input
                            type="text"
                            name="no_hp"
                            class="form-control"
                            placeholder="Masukkan nomor HP"
                            value="<?= htmlspecialchars($form['no_hp'] ?? ''); ?>"
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label fw-bold">Status Akun</label>

                        <select name="aktif" class="form-select">

                            <option value="1"
                                <?= ((int)$form['aktif'] === 1) ? 'selected' : ''; ?>>
                                Aktif
                            </option>

                            <option value="0"
                                <?= ((int)$form['aktif'] === 0) ? 'selected' : ''; ?>>
                                Tidak Aktif
                            </option>

                        </select>

                    </div>

                </div>

                <div class="mt-3">

                    <button
                        type="submit"
                        class="btn btn-stabilo btn-sm"
                    >
                        Simpan Perubahan
                    </button>

                    <a
                        href="kelola_guru.php"
                        class="btn btn-outline-secondary btn-sm"
                    >
                        Batal
                    </a>

                </div>

            </form>

        </div>

    </div>

</div>

</body>
</html>
